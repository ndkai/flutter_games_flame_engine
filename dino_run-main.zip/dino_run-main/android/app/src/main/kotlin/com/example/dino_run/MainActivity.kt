package com.example.dino_run

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
